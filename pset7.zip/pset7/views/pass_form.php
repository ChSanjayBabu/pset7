<form action="password.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="password" placeholder="Enter current password" type="password"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="new_pass" placeholder="Enter new password" type="password"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="confirmation" placeholder="retype new password" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Change password
            </button>
        </div>
    </fieldset>
</form>

