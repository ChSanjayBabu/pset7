<div>
    <h3>Your password is changed successfully!</h3>
</div>
<div class="container">
    <div id="top">
        <ul class="nav nav-pills">
            <li><a href="index.php"><strong>Home Page</strong></a></li>
        </ul>
    </div>
</div>